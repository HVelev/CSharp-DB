﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Footballers;Trusted_Connection=True";
    }
}
